const API_BASE = import.meta.env.VITE_API_BASE || '/api'

export function buildQuery(params = {}) {
  const sp = new URLSearchParams()
  Object.entries(params).forEach(([k, v]) => {
    if (v === undefined || v === null || v === '' ) return
    sp.set(k, String(v))
  })
  const q = sp.toString()
  return q ? `?${q}` : ''
}

export async function getJSON(path, { headers, ...opts } = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { 'Content-Type': 'application/json', ...(headers || {}) },
    ...opts
  })
  if (!res.ok) {
    const text = await res.text().catch(() => '')
    throw new Error(`HTTP ${res.status}: ${text || res.statusText}`)
  }
  return res.json()
}
