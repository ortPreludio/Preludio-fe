import { getJSON, buildQuery } from './client.js'
export function fetchPublicEvents(params = {}) {
  return getJSON(`/events/public${buildQuery(params)}`)
}
export function fetchEventsWithToken(token, params = {}) {
  return getJSON(`/events${buildQuery(params)}`, {
    headers: { Authorization: `Bearer ${token}` }
  })
}
