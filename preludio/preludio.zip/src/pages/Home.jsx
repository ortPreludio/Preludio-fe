import { Header } from '../components/layout/Header.jsx'
import { Hero } from '../components/layout/Hero.jsx'
import { Section } from '../components/layout/Section.jsx'
import { EventGrid } from '../components/organisms/EventGrid.jsx'
import { useEvents } from '../hooks/useEvents.js'

export function Home() {
  const { items, loading, error, setParams } = useEvents({ sort: 'fecha', order: 'asc', limit: 12 })

  return (
    <div className="page">
      <Header />
      <Hero />
      <Section title="Nuevos shows">
        <div className="toolbar">
          <label>Orden:
            <select onChange={(e)=> setParams(p => ({...p, order: e.target.value}))} defaultValue="asc">
              <option value="asc">Ascendente</option>
              <option value="desc">Descendente</option>
            </select>
          </label>
          <label>Categoría:
            <select onChange={(e)=> setParams(p => ({...p, categoria: e.target.value || undefined}))}>
              <option value="">Todas</option>
              <option value="Concierto">Concierto</option>
              <option value="Teatro">Teatro</option>
              <option value="Deporte">Deporte</option>
              <option value="Festival">Festival</option>
              <option value="Otro">Otro</option>
            </select>
          </label>
        </div>

        {loading && <div className="loader">Cargando eventos…</div>}
        {error && <div className="error">Error: {error}</div>}
        {!loading && !error && <EventGrid items={items} />}
      </Section>
    </div>
  )
}
