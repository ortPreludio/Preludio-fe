import { Home } from './pages/Home.jsx'
export default function App() { return <Home /> }
